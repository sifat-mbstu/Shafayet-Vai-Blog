<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US"
	itemscope 
	itemtype="http://schema.org/WebSite" 
	prefix="og: http://ogp.me/ns#" >
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US"
	itemscope 
	itemtype="http://schema.org/WebSite" 
	prefix="og: http://ogp.me/ns#" >
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>শাফায়েতের ব্লগ &lsaquo; Log In</title>
	<script type='text/javascript' src='http://www.shafaetsplanet.com/planetcoding/wp-admin/load-scripts.php?c=0&amp;load%5B%5D=jquery-core,jquery-migrate&amp;ver=bcb4227fbb2910e2249be1b5c4e2834a'></script>
<script type='text/javascript' src='http://www.shafaetsplanet.com/planetcoding/wp-content/plugins/banglkb/js/engine.js'></script>
<script type='text/javascript' src='http://www.shafaetsplanet.com/planetcoding/wp-content/plugins/banglkb/js/driver.phonetic.js'></script>
<script type='text/javascript' src='http://www.shafaetsplanet.com/planetcoding/wp-content/plugins/banglkb/js/driver.probhat.js'></script>
<script type='text/javascript' src='http://www.shafaetsplanet.com/planetcoding/wp-content/plugins/banglkb/js/banglakb.js'></script>
<link rel='stylesheet' href='http://www.shafaetsplanet.com/planetcoding/wp-admin/load-styles.php?c=0&amp;dir=ltr&amp;load%5B%5D=dashicons,buttons,forms,l10n,login&amp;ver=bcb4227fbb2910e2249be1b5c4e2834a' type='text/css' media='all' />
<link rel='stylesheet' id='github-badge-css'  href='http://www.shafaetsplanet.com/planetcoding/wp-content/plugins/github-badge/github-badge.css' type='text/css' media='all' />
<link rel='stylesheet' id='open-sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&#038;subset=latin%2Clatin-ext&#038;ver=bcb4227fbb2910e2249be1b5c4e2834a' type='text/css' media='all' />
<link rel='stylesheet' id='cptch_stylesheet-css'  href='http://www.shafaetsplanet.com/planetcoding/wp-content/plugins/captcha/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='cptch_desktop_style-css'  href='http://www.shafaetsplanet.com/planetcoding/wp-content/plugins/captcha/css/desktop_style.css' type='text/css' media='all' />
<script type='text/javascript' src='http://shafaetsplanet.api.oneall.com/socialize/library.js'></script>
<meta name='robots' content='noindex,follow' />
	</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
	<div id="login">
		<h1><a href="https://wordpress.org/" title="Powered by WordPress" tabindex="-1">শাফায়েতের ব্লগ</a></h1>
	
<form name="loginform" id="loginform" action="http://www.shafaetsplanet.com/planetcoding/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
	<p class="cptch_block"><script class="cptch_to_remove">
				(function( timeout ) {
					setTimeout(
						function() {
							var notice = document.getElementById("cptch_time_limit_notice_41");
							if ( notice )
								notice.style.display = "block";
						},
						timeout
					);
				})(120000);
			</script>
			<span id="cptch_time_limit_notice_41" class="cptch_time_limit_notice cptch_to_remove">Time limit is exhausted. Please reload CAPTCHA.</span><span class="cptch_wrap">
				<label class="cptch_label" for="cptch_input">
					<span class="cptch_span"><img class="cptch_img " src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAABhQTFRF////m5ubAAAAysrKZGRkJycn4uLi8/Pz4CtFhgAABmNJREFUeNrs3AtqXUcQRdHXn9s1/xkHTEKcyBG0JExUZ+0hmMWxqnXt11R0L38EAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAAQAAP4IABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJA6QBe/9cWANkADgAWAAALAIAFAMACAGABALAAAFgAACwAABYAAAsAgAUAwAIAYAEAsAAAWAAALAAAFgAACwCABQDAAgBgAQCwAABYAAAsAAAWAAALAIAFAOBbAdgARAP4ln8DAPBl1QAgG8AEIBrAACAbwANANIA1AYgGsAGIBvBdB+A7Anh+VytgAPw/ge9Aq/Y3IADvNfrfgAB81QA8AEQPwJoAtOv0fwQC4L0BqIgBAOArBmAD0K7d/kMAAN5tRdyAAHzFANQEwAAA0KrnlXEDAvBfN2DGIxAAXzEAG4DoATgTgHZVzgAA8MkB+PZ/fgC87cTcgAD8qp1zAwLwq1bODQjAJwegNgAGAIBWJT0CAfDJATgTgHYDUEk3IABvunkEqgcAAwBArwGopEcgAN50sm5AAP7VDrsBAfjEAJwJQPQADADatWI+BgfglwNQeQMAwM834CvtBgTg565+DbQmAMkDUBuAdgNQiQMAwMd+AtgAtCvwEQiAjw7AAKBdK+1DAAD+0Q4dAAA+MACNfgQE4CMDsCYA7QagQgcAgB9dPQKdCYAbEIBWA/AK/BAAAAMAwJ9V4ocAAPw9AJV6AwLwoxP5IQAAf3X1CHQmAN2KfQUG4H4AagIQPQADgG5dPQJ1uwEBuPwQZE0Aug1AZQ9APIARfQMCcPcKvAEwAAC06mTfgPEA7l6BHwAMAACxA/B6AOjWegV/CADA5SvwBiB6AM4EoNsA3DwC1QCgWyP7Q4B4AHe/BhoAtBuAcgNGAzjhHwKkA9huwGwAxyNQNAADEA5guQGjAWw3YDaAuwF4AGjW3a+BOg9AKIDhQ4BoAHevwGsCED0AG4BulQ8BogHc/R54ANCtUx6BkgFsN2A2gOUGjAZwNwBrAtBtAMoNmAzgMQDZAJZHoGgAd6/ANQFo1nADZgMoHwJEAxh+BMwGcDwCRQPwCBQO4LgBowHcDcCZADRruQGjAdy9AtcEwAAA0GkAyg0YDcAjUDaAywHYAEQPwJkANMsjUDaA7QbMBnDcgNEA7gYg5QYMArDcgNEALn8C2AB0GwD/I0A0AI9A4QA8AmUDuByAAUD0ANQDQLM8AmUDGB6BsgEcj0DRAC5fgTcAzVpuwGgAlwMwAIgegJoA9OoxANkA3IDZAC4HYE0AkgegNgDNKgMQDWB4BMoGcDwCRQPwCBQO4PgQIBqAAQgHsDwCRQPwCBQOYLkBowFcfgt8JgC9Gn4EjAZwOQA1AWg2AP41SDaA4waMBrDdgNkAjg8BogFcDsCZAPTKI1A2gO0GzAbgESgbwOWvgeoBIHkAak0Aeg1AeQSKBjDcgNkAyg0YDcAjUDiA4waMBnA5ADUB6NUyANEALgcg+gZsCWD5B8HRAB43YDYAj0DZAC5/DRQ/AO0ADDdgNoByA0YDGG7AbADHhwDRALYfAbMBXL4CG4BmAAxAOIDlBowGcPsI5AZsBmD5GDz+DBQAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAAEAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAANDv7w8BBgD+EJsHLsyzfwAAAABJRU5ErkJggg==" alt="image"/></span>
					<span class="cptch_span">&nbsp;&minus;&nbsp;</span>
					<span class="cptch_span"><img class="cptch_img " src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAABhQTFRFnJyc////xsbGaWlp3t7eAAAAKysr8fHxa2vRbAAACMBJREFUeNrs3VGSozgQANESYHT/G69jf2YidmK2u41QFXp5gyxSAtsY4oWlCSMQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQgACMQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQACXcZ57xHb03lrvxxax7yWHW8EjXQDvmR3tP/R2xH6WOvhFPHIFcP5paL/YokgDhTwyBbBv7xXyP2wFTgalPCLPomlfJPc2UM0jqo0tdwL1PHIE8K2x/Tu6pJ+p6nlkmOTe27fpCa8FSnrMD+Dc2o/Ykp0HinrE/GXTfza4ZJtAVY/ZAUT7gERXAmU9ouS2me00UNhjagDn0T7kSFFAZY+ZAZy9fUxPUEBpj6g9tzfnE47/PI95AZztGmbvAcU9ovi6mV5AdY9ZAXx+3ZTjSrC8x6wAtnYh27wAyntMCiDapUw7kdX3mDO6vV3MpG9TH+AxJYDrLpzmXkA9wWNKAFu7fHAbjzoBXL5xTjoJPMJjRgB9xOA6jyoBRBtC8KgRwNkGcfIoEUCMGlzwqBDAsIVz89J5ikc8ZgO4eek8xqP8dye/wSN/APvAud35GfopHrcHcIwc3MEjewBnG8rJI3kAMXZwwSN5AMfYwR08cgcweOe8be98isftAeyjB7fzSB1AjB5c8EgdwDF6cAePzAEMP3XedPJ8iocABHBvAPv4we08EgcQ4wcXPATAI2sA2/jBbTwSB3CMH9zBI3EAffzgOg8B8MgaQLsBHgLg4RTAQwA8fAzk4YsgHgLgsdBvAT14JA7Az8GL/xzshhB3BAlg5QDcFLr4TaFuC093P4g/hizt8fLXsLU9Xv4curiHv4cv7uEBEYt7eETM6h4eErW4x6MeE3fnw/af4uFBkct73B2AR8Xm8vCw6MU9PC5+cQ8vjFjcwytjFvfw0qjFPR7y2ri28SgUgBdH5vHw6tjFPbw8enEPr49f3GNWAOeFv6ce57wAyntM2zyvu4DqE49/fY+oP7mpx7+8R0yc3APWf32PKL525h//4h4xdXJH5eu/Z3jE3Ml9+ClqS3H8S3vE5NF99E1KvNJQ1mP6DPcfn0D7/kpEVY8ou31m2f6Le0TRxZNr+Rf2yHEajcJn/+IeSSZ5fmt0cb6SUs8j8ozuixtoz3v4K3ok2kvP/Qvfpxx76sNfzyOSLZ+/zu6I9Ee/nEfkWz9/Hl6PvcjRr+WR8nL6fE8vtqO/z6a9H9v2nlmpg1/JI15YGgEIAAKAACAACAACgAAgAAgAAoAAIAAIAAKAACAACAACgAAgAAgAAoAAIAAIAAKAACAACAACgAAgAAgAAoAAIAAIAAKAACAACAACgAAgAAgAAoAAIAAIAAKAACAACAACgAAgAAgAAoAAIAAIAAKAACAACAACgAAgAAgAAoAAIAAIAAKAACAACAACgAAgAAgAAoAAIAAIAAIQAAQAAUAAEAAEAAFAABDAPM5zj9iO3lvr/dgi9r3kcCt4pAvgPbOj/YfejtjPUge/iEeuAM4/De0XWxRpoJBHpgD27b1C/oetwMmglEfkWTTti+TeBqp5RLWx5U6gnkeOAL41tn9Hl/QzVT2PDJPce/s2PeG1QEmP+QGcW/sRW7LzQFGPmL9s+s8Gl2wTqOoxO4BoH5DoSqCsR5TcNrOdBgp7TA3gPNqHHCkKqOwxM4Czt4/pCQoo7RG15/bmfMLxn+cxL4CzXcPsPaC4RxRfN9MLqO4xK4DPr5tyXAmW95gVwNYuZJsXQHmPSQFEu5RpJ7L6HnNGt7eLmfRt6gM8pgRw3YXT3AuoJ3hMCWBrlw9u41EngMs3zkkngUd4zAigjxhc51ElgGhDCB41AjjbIE4eJQKIUYMLHhUCGLZwbl46T/GIx2wANy+dx3iU/+7kN3jkD2AfOLc7P0M/xeP2AI6Rgzt4ZA/gbEM5eSQPIMYOLngkD+AYO7iDR+4ABu+ct+2dT/G4PYB99OB2HqkDiNGDCx6pAzhGD+7gkTmA4afOm06eT/EQgADuDWAfP7idR+IAYvzggocAeGQNYBs/uI1H4gCO8YM7eCQOoI8fXOchAB5ZA2g3wEMAPJwCeAiAh4+BPHwRxEMAPBb6LaAHj8QB+Dl48Z+D3RDijiABrByAm0IXvynUbeHp7gfxx5ClPV7+Gra2x8ufQxf38PfwxT08IGJxD4+IWd3DQ6IW93jUY+LufNj+Uzw8KHJ5j7sD8KjYXB4eFr24h8fFL+7hhRGLe3hlzOIeXhq1uMdDXhvXNh6FAvDiyDweXh27uIeXRy/u4fXxi3vMCuC88PfU45wXQHmPaZvndRdQfeLxr+8R9Sc39fiX94iJk3vA+q/vEcXXzvzjX9wjpk7uqHz99wyPmDu5Dz9FbSmOf2mPmDy6j75JiVcaynpMn+H+4xNo31+JqOoRZbfPLNt/cY8ounhyLf/CHjlOo1H47F/cI8kkz2+NLs5XUup5RJ7RfXED7XkPf0WPRHvpuX/h+5RjT33463lEsuXz19kdkf7ol/OIfOvnz8PrsRc5+rU8Ul5On+/pxXb099m092Pb3jMrdfArecQLSyMAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAEAAEAAFAABAABAABQAAQAAQAAUAAAoAAIAAIAAKAACAACAACgAAgAAgAAoAAIAAIAA/jHwEGABhAHD83fh3DAAAAAElFTkSuQmCC" alt="image"/></span>
					<span class="cptch_span">&nbsp;=&nbsp;</span>
					<span class="cptch_span"><input id="cptch_input_41" class="cptch_input " type="text" autocomplete="off" name="cptch_number" value="" maxlength="2" size="2" aria-required="true" required="required" style="margin-bottom:0;display:inline;font-size: 12px;width: 40px;" /></span>
					<input type="hidden" name="cptch_result" value="wzI=" />
					<input type="hidden" name="cptch_time" value="1472748191" />
					<input type="hidden" value="Version: 4.2.2" />
				</label><span class="cptch_reload_button_wrap hide-if-no-js">
					<noscript>
						<style type="text/css">
							.hide-if-no-js {
								display: none !important;
							}
						</style>
					</noscript>
					<span class="cptch_reload_button dashicons dashicons-update"></span>
				</span></span></p><br /> <!-- OneAll.com / Social Login for WordPress / v5.0 -->
<div class="oneall_social_login">
 <div class="oneall_social_login_label" style="margin-bottom: 3px;"><label>Connect with:</label></div>
 <div class="oneall_social_login_providers" id="oneall_social_login_providers_2474572"></div>
 <script type="text/javascript">
  oneall.api.plugins.social_login.build('oneall_social_login_providers_2474572', {
   'providers': ['facebook','github','yahoo'], 
   'callback_uri': 'http://www.shafaetsplanet.com/planetcoding/wp-login.php?oa_social_login_source=login', 
   'css_theme_uri': 'http://public.oneallcdn.com/css/api/socialize/themes/wordpress/default.css' 
  });
 </script>
</div>	<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
		<input type="hidden" name="redirect_to" value="http://www.shafaetsplanet.com/planetcoding" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
<a href="http://www.shafaetsplanet.com/planetcoding/wp-login.php?action=register">Register</a> | 	<a href="http://www.shafaetsplanet.com/planetcoding/wp-login.php?action=lostpassword">Lost your password?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="http://www.shafaetsplanet.com/planetcoding/">&larr; Back to শাফায়েতের ব্লগ</a></p>
	
	</div>

	
	<script type='text/javascript'>
/* <![CDATA[ */
var cptch_vars = {"nonce":"f21e404995","ajaxurl":"http:\/\/www.shafaetsplanet.com\/planetcoding\/wp-admin\/admin-ajax.php","enlarge":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.shafaetsplanet.com/planetcoding/wp-content/plugins/captcha/js/front_end_script.js'></script>
	<div class="clear"></div>
	</body>
	</html>
	